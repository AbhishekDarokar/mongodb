import pymongo
try:
     client=pymongo.MongoClient("mongodb://localhost:27017")
     db=client["office"]
     coll=db["workers"]
     d={}
     id=int(input("enter id : "))
     d["_id"]=id
     info={}
     city=input("enter city : ")
     info["city"]=city
     dept=input("enter dept: ")
     info["dept"]=dept
     upd={"$set":info}
     coll.update_one(d,upd)
     print("Salary Updated successfully! ")
except Exception as e:
    print(" Invalid id !")
    print(e)