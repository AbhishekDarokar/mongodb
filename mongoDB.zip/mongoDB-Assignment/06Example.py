import pymongo
try:
     client=pymongo.MongoClient("mongodb://localhost:27017")
     db=client["office"]
     coll=db["workers"]
     
     for doc in coll.find():
        print("Employee no:",doc["_id"])
        print("-"*30)
        print("id: ",doc["_id"])
        print("name: ",doc["empnm"])
        print("department: ",doc["dept"])
        print("post: ",doc["post"])
        print("city: ",doc["city"])
        print("salary: ",doc["salary"])
        print("mobile: ",doc["mobile"])
        print("email: ",doc["email"])
        print("\n")
except Exception as e:
    print(" No record found !")
    print(e)