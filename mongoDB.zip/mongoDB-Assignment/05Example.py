import pymongo
try:
     client=pymongo.MongoClient("mongodb://localhost:27017")
     db=client["office"]
     coll=db["workers"]
     d={}
     id=int(input("Enter id: "))
     empnm=input("Enter name: ")
     dept=input("department name: ")
     post=input("Enter post: ")
     city=input("Enter city: ")
     salary=int(input("Enter salary: "))
     mobile=input("Enter mobile number: ")
     email=input("Enter email id: ")
     d["_id"]=id
     d["empnm"]=empnm.lower()
     d["dept"]=dept.lower()
     d["post"]=post.lower()
     d["city"]=city.lower()
     d["salary"]=salary
     d["mobile"]=mobile
     d["email"]=email
     coll.insert_one(d)
     print("\nData enter successfully !")
except Exception as e:
    print("\nData not added !")
    print("1. error our.")
    print("2. Duplicate data enter, Enter data carefully.")