import pymongo
clinet=pymongo.MongoClient("mongodb://localhost:27017")
try:
     client=pymongo.MongoClient("mongodb://localhost:27017")
     db=client["office"]
     coll=db["workers"]
     d={}
     id=int(input("enter id: "))
     d["_id"]=id
     for doc in coll.find(d):
         print("\nInformation:")
         print("-"*30)
         print("name      : ",doc["empnm"])
         print("department: ",doc["dept"])
         print("post      : ",doc["post"])
         print("city      : ",doc["city"])
         print("salary    : ",doc["salary"])
         print("mobile    : ",doc["mobile"])
         print("email     : ",doc["email"])
         print("\n")
except Exception as e:
    print(" Invalid id !")
    print(e)