import pymongo
try:
     client=pymongo.MongoClient("mongodb://localhost:27017")
     db=client["office"]
     coll=db["workers"]
     d={}
     id=int(input("enter id : "))
     d["_id"]=id
     sal={}
     salary=input("enter salary : ")
     sal["salary"]=salary
     update={"$set":sal}
     coll.update_one(d,update)
     print("Salary Updated successfully! ")
except Exception as e:
    print(" Invalid id !")
    print(e)