import pymongo
try:
     client=pymongo.MongoClient("mongodb://localhost:27017")
     db=client["office"]
     coll=db["workers"]
     print("python connected to mongoDB")
except Exception as e:
    print("DataBase not Connected : exception")
    print(e)